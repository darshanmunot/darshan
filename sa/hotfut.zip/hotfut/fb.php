<?php
include('config.php');
$name=$_POST['t1'];
$email=$_POST['t2'];
$address=$_POST['t3'];
$phone=$_POST['t4'];
$feedback=$_POST['t5'];

$result=mysqli_query($con,"insert into feedbacks values(default,'$name','$email','$address','$phone','$feedback');") or die("Unable to Insert");



$res=mysqli_query($con,"select * from feedbacks  where name='$name';") or die("Unable to Select");


echo"<table border=1 width=60% align=center>";

echo"<tr><th>Id</th><th>Name</th><th>Mail</th><th>Address</th><th>Phone</th><th>Feedback</th></tr>";

while($r=mysqli_fetch_array($res))
{
echo"<tr>";
echo"<td>".$r[0]."</td>";
echo"<td>".$r[1]."</td>";
echo"<td>".$r[2]."</td>";
echo"<td>".$r[3]."</td>";
echo"<td>".$r[4]."</td>";
echo"<td>".$r[5]."</td>";
echo"</tr>";
}

?>


