
<?php
session_start();   
if(isset($_POST['check']))    
{
$username="admin";   
$password="123";       
if($_POST['username']==$username && $_POST['password']==$password)   
{
$_SESSION['username']=$username;    
header('location:view.html');
}
else
{
echo "<p> <font color=red> Wrong Username or Password !!!!</font> </p>";
}
}
?>

<html>
<head>

<link rel="stylesheet" type="text/css" href="ex.css">  
</head>
<body>

<?php if(isset($err)){ echo $err; } ?>      

<form method="POST" name="loginauth" target="_self">

            <font face="Times" size="3" color="white">Username:</font><input type="text" name="username" required=required placeholder="Enter Username"><br><br><br><br>

<br/><br/>
            <font face="Times" size="3" color="white">Password:</font><input type="password" name="password" required=required placeholder="Enter Username"><br><br><br><br>

<br/><br/>
<input name="check" type="submit" value="Login">

</form>

</body>
</html>
