<html>
<head>
<title>HOTFUT</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<link rel="stylesheet" type="text/css" href="ex.css">
</head>
<body> 
 <style>
 .h1{
	 
 }
 </style>
 
 <h1  style="color:White ;">DELETE FORM HERE: </h1><br>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
<p style="color:white;">ENTER CUSTOMER'S ID:</p><br>
<input type="number" name="id" placeholder="Enter  ID" required="required"><br><br><br>
<input type="submit" name="submit" class="btn btn-light" value="DELETE RECORD">
</form>
<?php
include('config.php');


if(isset($_POST['submit']))
{

$id=$_POST['id'];

$res=mysqli_query($con,"delete from ground where id=$id;")or die("OOPS SOMETHING WENT WRONG");

echo "<script>alert('RECORD DELETED');window.location='view1.php';</script>";
}
?>
</div>
</body>
</html>